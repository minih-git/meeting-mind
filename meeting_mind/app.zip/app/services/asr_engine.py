import os
import copy
import time
import numpy as np
from funasr import AutoModel
from meeting_mind.app.core.config import settings
from meeting_mind.app.core.logger import logger


class ASREngine:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ASREngine, cls).__new__(cls)
            cls._instance.asr_model = None
            cls._instance.vad_model = None
            cls._instance.punc_model = None
            cls._instance.cache = (
                {}
            )  # session_id -> {asr_cache, vad_cache, punc_cache} 会话缓存
            cls._instance.speaker_registry = {}  # speaker_id -> embedding
        return cls._instance

    def load_models(self):
        """分别加载 FunASR 模型到内存中。"""
        if self.asr_model is not None:
            logger.info("模型已加载。")
            return

        logger.info("正在加载 FunASR 模型...")
        try:
            # 加载 ASR 模型
            logger.info("  - 加载 ASR 模型...")
            self.asr_model = AutoModel(
                model=settings.ASR_MODEL_PATH, disable_update=True
            )
            logger.info("  ✓ ASR 模型加载成功")

            # 加载 VAD 模型
            logger.info("  - 加载 VAD 模型...")
            self.vad_model = AutoModel(
                model=settings.VAD_MODEL_PATH, disable_update=True
            )
            logger.info("  ✓ VAD 模型加载成功")

            # 加载标点模型
            logger.info("  - 加载标点模型...")
            try:
                self.punc_model = AutoModel(
                    model=settings.PUNC_MODEL_PATH, disable_update=True
                )
                logger.info("  ✓ 标点模型加载成功")
            except Exception as e:
                logger.warning(f"  ⚠ 标点模型加载失败 (将继续运行但无标点): {e}")
                self.punc_model = None

            # 加载说话人模型
            logger.info("  - 加载说话人模型...")
            self.speaker_model = AutoModel(
                model=settings.SPEAKER_MODEL_PATH, disable_update=True
            )
            logger.info("  ✓ 说话人模型加载成功")

            logger.info("🎉 所有模型加载完成!")
        except Exception as e:
            logger.error(f"❌ 加载模型出错: {e}")
            raise e

    def _cosine_similarity(self, v1, v2):
        """计算两个向量的余弦相似度"""
        # Ensure 1D arrays
        v1 = np.squeeze(v1)
        v2 = np.squeeze(v2)
        
        norm1 = np.linalg.norm(v1)
        norm2 = np.linalg.norm(v2)
        if norm1 == 0 or norm2 == 0:
            return 0.0
        return np.dot(v1, v2) / (norm1 * norm2)

    def detect_gender(self, audio_chunk: bytes):
        """
        基于音高检测性别 (Heuristic)
        Male: < 165Hz
        Female: > 165Hz
        """
        try:
            import librosa
            # Convert to float32
            audio_np = np.frombuffer(audio_chunk, dtype=np.int16).astype(np.float32) / 32768.0
            
            # Use librosa.pyin for pitch tracking
            # Frame length ~ 30ms
            f0, voiced_flag, voiced_probs = librosa.pyin(
                audio_np, 
                fmin=librosa.note_to_hz('C2'), 
                fmax=librosa.note_to_hz('C7'),
                sr=16000
            )
            
            # Filter NaN
            f0 = f0[~np.isnan(f0)]
            
            if len(f0) == 0:
                return "未知"
            
            avg_pitch = np.mean(f0)
            logger.debug(f"检测到的音高: {avg_pitch:.2f} Hz")
            
            if avg_pitch < 165:
                return "男"
            else:
                return "女"
        except Exception as e:
            logger.error(f"性别检测失败: {e}")
            return "未知"

    def recognize_speaker(self, audio_segment: bytes):
        """
        提取说话人声纹特征并识别说话人。
        """
        if not self.speaker_model:
            logger.warning("说话人模型未加载")
            return "未知"

        if len(audio_segment) < 16000 * 0.5 * 2:  # Min 0.5s (16k * 2 bytes)
            logger.debug(f"音频片段太短，无法进行说话人识别: {len(audio_segment)} 字节")
            return "未知"

        try:
            # 将字节转换为 numpy 数组
            audio_np = (
                np.frombuffer(audio_segment, dtype=np.int16).astype(np.float32)
                / 32768.0
            )

            res = self.speaker_model.generate(input=audio_np, disable_pbar=True)

            if isinstance(res, list) and len(res) > 0:
                embedding = res[0].get("spk_embedding")
                if embedding is not None:
                    # 简单的说话人聚类/识别逻辑
                    # 阈值通常在 0.25 - 0.4 之间，取决于模型
                    # 降低阈值以提高召回率
                    THRESHOLD = 0.25

                    best_score = -1.0
                    best_speaker = None

                    # 与注册的说话人进行比较
                    for spk_id, data in self.speaker_registry.items():
                        spk_emb = data["embedding"]
                        score = self._cosine_similarity(embedding, spk_emb)
                        if score > best_score:
                            best_score = score
                            best_speaker = spk_id

                    logger.debug(f"说话人匹配得分: {best_score:.4f} (匹配: {best_speaker})")

                    if best_score > THRESHOLD:
                        # 在线更新：更新声纹中心
                        # new_center = alpha * old_center + (1-alpha) * new_emb
                        # alpha 可以是固定的，也可以基于计数
                        old_emb = self.speaker_registry[best_speaker]["embedding"]
                        count = self.speaker_registry[best_speaker]["count"]
                        
                        # 简单的加权平均
                        alpha = 0.8 # 保持旧特征的权重
                        new_emb = alpha * old_emb + (1 - alpha) * np.squeeze(embedding)
                        # 归一化
                        new_emb = new_emb / np.linalg.norm(new_emb)
                        
                        self.speaker_registry[best_speaker]["embedding"] = new_emb
                        self.speaker_registry[best_speaker]["count"] = count + 1
                        
                        gender = self.speaker_registry[best_speaker]["gender"]
                        return f"{best_speaker} ({gender})"
                    else:
                        # 注册新说话人
                        gender = self.detect_gender(audio_segment)
                        
                        new_id = f"Speaker_{len(self.speaker_registry) + 1}"
                        self.speaker_registry[new_id] = {
                            "embedding": np.squeeze(embedding),
                            "gender": gender,
                            "count": 1
                        }
                        logger.info(f"注册新说话人: {new_id} ({gender}) (得分: {best_score:.4f})")
                        return f"{new_id} ({gender})"

            logger.debug("未找到说话人嵌入")
            return "未知"
        except Exception as e:
            logger.error(f"说话人识别错误: {e}")
            return "未知"

    def check_audio_quality(
        self, audio_chunk: bytes, min_energy_threshold: float = 100.0
    ):
        """
        检查音频质量,过滤静音或低能量片段。

        Args:
            audio_chunk: 音频字节数据
            min_energy_threshold: 最小能量阈值

        Returns:
            dict: {"is_valid": bool, "energy": float, "max_amplitude": int}
        """
        if len(audio_chunk) == 0:
            return {"is_valid": False, "energy": 0.0, "max_amplitude": 0}

        try:
            # 转换为numpy数组
            audio_np = np.frombuffer(audio_chunk, dtype=np.int16)

            # 计算最大振幅
            max_amp = np.max(np.abs(audio_np))

            # 计算能量 (RMS)
            audio_float = audio_np.astype(np.float32)
            energy = np.sqrt(np.mean(audio_float**2))

            # 判断是否为有效语音
            is_valid = energy >= min_energy_threshold and max_amp > 50

            return {
                "is_valid": is_valid,
                "energy": float(energy),
                "max_amplitude": int(max_amp),
            }

        except Exception as e:
            logger.error(f"音频质量检测错误: {e}")
            # 出错时假设音频有效,避免丢失数据
            return {"is_valid": True, "energy": 0.0, "max_amplitude": 0}

    def inference_stream(
        self, session_id: str, audio_chunk: bytes, is_final: bool = False
    ):
        """
        处理特定会话的音频流。
        使用 VAD 进行分段，仅在检测到完整句子（VAD 片段结束）时触发 ASR 和说话人识别。
        """
        if self.asr_model is None:
            raise RuntimeError("Models not loaded. Call load_models() first.")

        # 为新会话初始化缓存
        if session_id not in self.cache:
            self.cache[session_id] = {
                "asr": {},
                "vad": {},
                "punc": {},
                "audio_buffer": bytearray(),  # 累积音频缓冲区
                "buffer_offset_ms": 0,        # 缓冲区起始时间相对于会话开始的偏移量
                "vad_state": {                # 跟踪 VAD 状态
                    "current_start_ms": -1,
                    "segments": []
                }
            }

        session_cache = self.cache[session_id]
        
        # 1. 追加到缓冲区
        session_cache["audio_buffer"].extend(audio_chunk)
        
        # 转换当前 chunk 为 float32 用于 VAD
        # 注意：VAD 需要流式输入，这里我们只传入新到达的 chunk
        if len(audio_chunk) > 0:
            audio_np = (
                np.frombuffer(audio_chunk, dtype=np.int16).astype(np.float32)
                / 32768.0
            )
        else:
            audio_np = np.array([], dtype=np.float32)

        # 2. 运行 VAD (连续)
        vad_segments = []
        if len(audio_np) > 0:
            try:
                vad_res = self.vad_model.generate(
                    input=audio_np,
                    cache=session_cache["vad"],
                    is_final=is_final,
                    batch_size=1,
                    chunk_size=200, # VAD chunk size
                    disable_pbar=True,
                )
                # VAD 返回的是相对于本次输入流的绝对时间戳（如果 cache 正确维护）
                # FunASR VAD 输出格式通常是 [[start, end], ...] 毫秒
                if isinstance(vad_res, list) and len(vad_res) > 0:
                    vad_segments = vad_res[0].get("value", [])
            except Exception as e:
                logger.error(f"[{session_id[:8]}] VAD 错误: {e}")

        results = []
        
        # 3. 处理 VAD 片段
        # 我们需要维护一个全局的 VAD 状态，因为 segments 可能跨越 chunk
        
        for seg in vad_segments:
            start_ms, end_ms = seg
            
            # VAD 输出 -1 表示未开始或未结束
            if start_ms != -1:
                session_cache["vad_state"]["current_start_ms"] = start_ms
                # print(f"[{session_id[:8]}] Speech started at {start_ms}ms")
            
            if end_ms != -1:
                # 句子结束
                start_ms_stored = session_cache["vad_state"]["current_start_ms"]
                
                # 如果没有记录开始时间（可能在上一次请求中丢失，或者 VAD 逻辑问题），
                # 尝试使用缓冲区开头或合理的默认值。
                # 但通常 VAD 会成对出现。
                
                if start_ms_stored != -1:
                    # print(f"[{session_id[:8]}] Speech ended at {end_ms}ms (duration: {end_ms - start_ms_stored}ms)")
                    
                    # 提取该片段的音频
                    # 需要将绝对时间戳转换为当前 buffer 的相对偏移
                    # buffer_start_time = session_cache["buffer_offset_ms"]
                    # segment_start_in_buffer = start_ms_stored - buffer_start_time
                    # segment_end_in_buffer = end_ms - buffer_start_time
                    
                    # 简化逻辑：我们假设 buffer 包含了从一开始到现在的所有未处理音频
                    # 但为了内存，我们需要丢弃旧数据。
                    # 这里我们需要一个策略：
                    # VAD 返回的时间戳是相对于 *整个会话* 的吗？
                    # FunASR VAD with cache 应该是返回相对于流开始的时间戳。
                    
                    # 计算 byte 偏移 (16kHz, 16bit = 32 bytes/ms)
                    # 但是 buffer 可能会被截断。
                    # 让我们假设 buffer 始终包含我们需要的数据，直到我们显式删除它。
                    # 为了正确映射，我们需要知道 buffer[0] 对应的时间戳。
                    
                    buffer_offset_ms = session_cache["buffer_offset_ms"]
                    
                    rel_start_ms = start_ms_stored - buffer_offset_ms
                    rel_end_ms = end_ms - buffer_offset_ms
                    
                    if rel_start_ms < 0:
                        # 说明开始点已经被移出 buffer 了，这是一个问题。
                        # 我们应该保留 buffer 直到处理完。
                        rel_start_ms = 0 # Fallback
                        
                    start_byte = int(rel_start_ms * 32)
                    end_byte = int(rel_end_ms * 32)
                    
                    if end_byte <= len(session_cache["audio_buffer"]):
                        segment_audio = session_cache["audio_buffer"][start_byte:end_byte]
                        
                        # 4. 对该片段进行 ASR 和 说话人识别
                        if len(segment_audio) > 16000 * 0.2 * 2: # 忽略极短片段 (<200ms)
                            
                            # A. 说话人识别
                            speaker_id = self.recognize_speaker(segment_audio)
                            
                            # B. ASR 识别
                            seg_audio_np = (
                                np.frombuffer(segment_audio, dtype=np.int16).astype(np.float32)
                                / 32768.0
                            )
                            
                            asr_text = ""
                            try:
                                # 使用 SenseVoice 或 Paraformer 进行整句识别
                                # 注意：这里不使用 cache，因为是独立的句子
                                asr_res = self.asr_model.generate(
                                    input=seg_audio_np,
                                    cache={}, # No cache for sentence-level
                                    is_final=True,
                                    batch_size=1,
                                    disable_pbar=True,
                                )
                                if isinstance(asr_res, list) and len(asr_res) > 0:
                                    asr_text = asr_res[0].get("text", "")
                                    # Clean SenseVoice tags
                                    import re
                                    asr_text = re.sub(r"<\|.*?\|>", "", asr_text).strip()
                            except Exception as e:
                                logger.error(f"ASR 错误: {e}")
                            
                            # C. 标点 (可选，SenseVoice 通常自带标点)
                            if asr_text and self.punc_model:
                                try:
                                    punc_res = self.punc_model.generate(
                                        input=asr_text,
                                        is_final=True,
                                        disable_pbar=True
                                    )
                                    if isinstance(punc_res, list) and len(punc_res) > 0:
                                        asr_text = punc_res[0].get("text", asr_text)
                                except Exception:
                                    pass

                            if asr_text:
                                logger.info(f"[{session_id[:8]}] 识别结果: {speaker_id} - {asr_text}")
                                results.append({
                                    "text": asr_text,
                                    "speaker_id": speaker_id,
                                    "timestamp": end_ms / 1000.0, # Use end time
                                    "vad_segment": [start_ms, end_ms]
                                })
                        
                        # 5. 清理 Buffer
                        # 我们可以安全地移除 end_byte 之前的数据
                        # 更新 offset
                        # 注意：如果有重叠说话或紧接着的句子，可能需要保留一点上下文？
                        # 简单起见，直接截断
                        
                        # 实际上，为了安全，我们只在 buffer 过大时或者确信不再需要时清理。
                        # 这里我们移除已处理的片段。
                        
                        # 优化：批量处理完后再截断，或者记录需要截断的位置
                        # 这里直接截断
                        del session_cache["audio_buffer"][:end_byte]
                        session_cache["buffer_offset_ms"] += (end_byte // 32)
                        
                    else:
                        logger.warning(f"[{session_id[:8]}] 片段超出缓冲区范围")

                    # Reset start
                    session_cache["vad_state"]["current_start_ms"] = -1

        # 6. 处理 is_final
        if is_final and len(session_cache["audio_buffer"]) > 0:
             # 处理剩余的所有音频
             remaining_audio = session_cache["audio_buffer"]
             if len(remaining_audio) > 16000 * 0.5 * 2:
                 speaker_id = self.recognize_speaker(remaining_audio)
                 seg_audio_np = np.frombuffer(remaining_audio, dtype=np.int16).astype(np.float32) / 32768.0
                 try:
                     asr_res = self.asr_model.generate(input=seg_audio_np, is_final=True, disable_pbar=True)
                     if isinstance(asr_res, list) and len(asr_res) > 0:
                         text = asr_res[0].get("text", "")
                         import re
                         text = re.sub(r"<\|.*?\|>", "", text).strip()
                         if text:
                             results.append({
                                 "text": text,
                                 "speaker_id": speaker_id,
                                 "timestamp": time.time(),
                                 "vad_segment": []
                             })
                 except Exception:
                     pass
             
             # Clean up
             del self.cache[session_id]

        return results

    def reset_session(self, session_id: str):
        """清除会话缓存。"""
        if session_id in self.cache:
            del self.cache[session_id]


asr_engine = ASREngine()
