import sys
from loguru import logger

# 移除默认的 handler
logger.remove()

# 添加控制台 handler，设置格式
logger.add(
    sys.stderr,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
    level="INFO",
)

# 如果需要，也可以添加文件 handler
# logger.add("logs/app.log", rotation="500 MB", level="INFO")

__all__ = ["logger"]
