from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from starlette.websockets import WebSocketState
import json
import time
import asyncio
import numpy as np
from meeting_mind.app.services.asr_engine import asr_engine
from meeting_mind.app.schemas.protocol import HandshakeMessage, RecognitionResult

import wave
import os
import datetime
from meeting_mind.app.services.session_mgr import session_manager
from meeting_mind.app.core.logger import logger

router = APIRouter()

@router.get("/history")
async def get_history():
    """获取历史会议列表"""
    return session_manager.get_history_list()

@router.get("/history/{meeting_id}")
async def get_history_detail(meeting_id: str):
    """获取特定会议的详细记录"""
    detail = session_manager.get_history_detail(meeting_id)
    if not detail:
        return {"error": "Meeting not found"}
    return detail

@router.get("/audio/{meeting_id}")
async def get_audio(meeting_id: str):
    """下载会议录音"""
    detail = session_manager.get_history_detail(meeting_id)
    if not detail or not detail.get("audio_file"):
        return {"error": "Audio not found"}
    
    filename = detail["audio_file"]
    filepath = os.path.join(os.getcwd(), "recordings", filename)
    
    if not os.path.exists(filepath):
        return {"error": "File not found on server"}
        
    return FileResponse(filepath, media_type="audio/wav", filename=filename)


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    session_id = None

    try:
        # 1. 握手
        # 期望包含 meeting_id 的 JSON
        data = await websocket.receive_text()
        try:
            handshake_data = json.loads(data)
            handshake = HandshakeMessage(**handshake_data)
            session_id = handshake.meeting_id

            # 验证会议 ID
            meeting = session_manager.get_meeting(session_id)
            if not meeting:
                logger.warning(f"无效的会议 ID: {session_id}")
                await websocket.close(code=1008, reason="无效的会议 ID")
                return

            if meeting.status != "active":
                logger.warning(f"会议 {session_id} 未激活")
                await websocket.close(code=1008, reason="会议未激活")
                return

            logger.info(f"会话 {session_id} 已连接。采样率: {handshake.sample_rate}")

            # 1.1 初始化录音文件
            recordings_dir = os.path.join(os.getcwd(), "recordings")
            os.makedirs(recordings_dir, exist_ok=True)
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            wav_filename = f"{session_id}_{timestamp}.wav"
            wav_path = os.path.join(recordings_dir, wav_filename)
            
            wav_file = wave.open(wav_path, "wb")
            wav_file.setnchannels(1)  # 单声道
            wav_file.setsampwidth(2)  # 16-bit
            wav_file.setframerate(handshake.sample_rate)
            logger.info(f"开始录音: {wav_path}")
            
            # 记录录音文件到会话
            session_manager.set_audio_file(session_id, wav_filename)
        except Exception as e:
            logger.error(f"握手失败: {e}")
            await websocket.close(code=1003)  # 不支持的数据
            return

        # 确保模型已加载
        if asr_engine.asr_model is None:
            pass

        # 2. 音频流循环
        while True:

            message = None
            try:
                message = await asyncio.wait_for(websocket.receive(), timeout=5.0)
            except asyncio.TimeoutError:
                # 发送 ping 以防止代理/浏览器超时
                try:
                    await websocket.send_text(json.dumps({"type": "ping"}))
                except Exception:
                    break
                
                # 检查是否需要刷新缓冲区
                if hasattr(websocket, "audio_buffer") and len(websocket.audio_buffer) > 0:
                     # 如果有数据待处理时间过长，强制处理
                     time_since_last = time.time() - websocket.last_process_time
                     if time_since_last >= MAX_WAIT_TIME:
                         # 通过超时逻辑强制处理
                         pass
                     else:
                         continue
                else:
                    continue
            except Exception as e:
                logger.error(f"接收错误: {e}")
                break

            if message and message["type"] == "websocket.receive":
                if "bytes" in message:
                    audio_chunk = message["bytes"]

                    # 在线程池中运行推理以避免阻塞事件循环
                    # import numpy as np
                    # audio_np = np.frombuffer(audio_chunk, dtype=np.int16)
                    # max_amp = np.max(np.abs(audio_np)) if len(audio_np) > 0 else 0

                    # Buffer audio locally just for chunking logic if needed, 
                    # but we can just pass through to engine which has its own buffer.
                    # However, to avoid too many small calls, we can buffer slightly here.
                    
                    if not hasattr(websocket, "audio_buffer"):
                        websocket.audio_buffer = bytearray()
                        websocket.last_process_time = time.time()

                    websocket.audio_buffer.extend(audio_chunk)
                    
                    # 写入录音文件
                    if wav_file:
                        wav_file.writeframes(audio_chunk)

                    # Streaming Strategy:
                    # Pass data to engine frequently (e.g. every 200ms) so VAD can work.
                    # 200ms * 16000 * 2 = 6400 bytes
                    PROCESS_CHUNK_SIZE = 6400 

                    if len(websocket.audio_buffer) >= PROCESS_CHUNK_SIZE:
                        process_chunk = bytes(websocket.audio_buffer)
                        websocket.audio_buffer = bytearray()  # Clear buffer
                        
                        loop = asyncio.get_event_loop()
                        # inference_stream now returns a LIST of results
                        results = await loop.run_in_executor(
                            None,
                            lambda: asr_engine.inference_stream(
                                session_id, process_chunk, is_final=False
                            ),
                        )
                        
                        # 处理结果列表
                        if isinstance(results, list):
                            for res in results:
                                if res.get("text"):
                                    logger.info(f"ASR 结果: {res['text']}")
                                    response = RecognitionResult(
                                        type="final",
                                        text=res["text"],
                                        speaker=res.get("speaker_id") or "Unknown",
                                        timestamp=res.get("timestamp") or time.time(),
                                        vad_segments=[res.get("vad_segment")] if res.get("vad_segment") else [],
                                        session_id=session_id,
                                    )
                                    session_manager.add_transcript(
                                        session_id, response.text, response.speaker
                                    )
                                    await websocket.send_text(response.model_dump_json())
                        elif isinstance(results, dict) and "error" in results:
                             logger.error(f"推理错误: {results['error']}")

                elif message and "text" in message and message["text"]:
                    # 处理控制消息
                    try:
                        control = json.loads(message["text"])
                        if control.get("type") == "stop":
                            logger.info(f"会话 {session_id} 已由客户端停止。")
                            try:
                                # 触发最终推理，传入剩余的 buffer
                                remaining_audio = bytes(websocket.audio_buffer) if hasattr(websocket, "audio_buffer") else b""
                                # Also flush engine buffer
                                loop = asyncio.get_event_loop()
                                results = await loop.run_in_executor(
                                    None,
                                    lambda: asr_engine.inference_stream(
                                        session_id, remaining_audio, is_final=True
                                    ),
                                )

                                if isinstance(results, list):
                                    for res in results:
                                        if res.get("text"):
                                            response = RecognitionResult(
                                                type="final",
                                                text=res["text"],
                                                speaker=res.get("speaker_id") or "Unknown",
                                                timestamp=time.time(),
                                                vad_segments=[res.get("vad_segment")] if res.get("vad_segment") else [],
                                                session_id=session_id,
                                            )
                                            session_manager.add_transcript(
                                                session_id, response.text, response.speaker
                                            )
                                            await websocket.send_text(response.model_dump_json())
                                            
                            except Exception as e:
                                print(f"Stop inference failed: {e}")
                            finally:
                                # 发送停止确认
                                await websocket.send_text(json.dumps({"type": "stopped"}))
                                await asyncio.sleep(0.1)
                                # 客户端发送停止，结束循环
                                break
                    except Exception as e:
                        logger.error(f"控制消息错误: {e}")

    except WebSocketDisconnect:
        logger.info(f"客户端已断开连接: {session_id}")
        if session_id:
            asr_engine.reset_session(session_id)
            # 尝试生成摘要（如果不是正常停止流程触发的断开）
            # 注意：如果客户端先发了 stop，这里可能重复调用，但 generate_meeting_summary 内部应该幂等或无害
            # 最好是在 stop_meeting 逻辑里统一处理，但这里作为兜底
            session_manager.generate_meeting_summary(session_id)
            
    except Exception as e:
        logger.error(f"WebSocket 错误: {e}")
        if session_id:
            asr_engine.reset_session(session_id)
        if websocket.client_state == WebSocketState.CONNECTED:
            await websocket.close()
    finally:
        if 'wav_file' in locals() and wav_file:
            wav_file.close()
            logger.info(f"录音已保存: {wav_path}")
            
        # 确保在会话结束时生成摘要
        if session_id:
             # 异步触发摘要生成，以免阻塞 websocket 关闭？
             # 这里是同步调用，可能会稍微延迟连接关闭，但对于生成标题来说是可以接受的
             session_manager.generate_meeting_summary(session_id)
